from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),
    path('cars/', views.car_list, name='cars-list'),
    path('cars/<slug:slug>/', views.car_detail, name='car-detail'),
    path('authors/', views.authors_list, name='authors-list'),
    path('authors/<int:pk>/', views.author_detail, name='author-detail'),
    path('tags/', views.tag_list, name='tags-list'),
    path('tags/<int:tag_id>/', views.posts_by_tag, name='tag-posts'),
]