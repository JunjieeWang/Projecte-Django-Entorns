import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Projecte_Django_Junjie_Wang.settings')

application = get_wsgi_application()
