from django.db import models
from django.urls import reverse

class Tag(models.Model):
    name = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('tag-detail', args=[self.id])

class Author(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField()

    def get_absolute_url(self):
        return reverse('author-detail', args=[self.id])

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class Car(models.Model):
    make = models.CharField(max_length=50)
    model = models.CharField(max_length=50)
    year = models.PositiveIntegerField()
    description = models.TextField()
    image = models.ImageField(upload_to='cars/')
    slug = models.SlugField(unique=True)
    created = models.DateTimeField(auto_now_add=True)
    author = models.ForeignKey('Author', on_delete=models.CASCADE, related_name='cars')
    tags = models.ManyToManyField(Tag, related_name='cars')




    def get_absolute_url(self):
        return reverse('car-detail', args=[self.slug])

    def __str__(self):
        return f"{self.make} {self.model} ({self.year})"
