from django.test import TestCase
from django.urls import reverse
from cotxes.models import Car, Author, Tag


class AuthorModelTest(TestCase):
    def test_str(self):
        author = Author(first_name="Ana", last_name="García", email="ana@example.com")
        self.assertEqual(str(author), "Ana García")

class TagModelTest(TestCase):
    def test_str(self):
        tag = Tag(name="Esportiu")
        self.assertEqual(str(tag), "Esportiu")

class CarModelTest(TestCase):
    def setUp(self):
        self.author = Author.objects.create(first_name="Joan", last_name="Pérez", email="joan@example.com")
        self.tag = Tag.objects.create(name="Híbrid")
        self.car = Car.objects.create(
            make="Ferrari",
            model="Testarossa",
            year=2020,
            description="Descripció de prova.",
            image="cars/fake.jpg",
            slug="ferrari-testarossa",
            author=self.author
        )
        self.car.tags.add(self.tag)

    def test_car_creation(self):
        self.assertEqual(self.car.make, "Ferrari")
        self.assertEqual(self.car.author.last_name, "Pérez")
        self.assertIn(self.tag, self.car.tags.all())

class URLTests(TestCase):
    def test_index_view_status(self):
        url = reverse('home')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_cars_list_view_status(self):
        url = reverse('cars-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_authors_list_view_status(self):
        url = reverse('authors-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_tags_list_view_status(self):
        url = reverse('tags-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
