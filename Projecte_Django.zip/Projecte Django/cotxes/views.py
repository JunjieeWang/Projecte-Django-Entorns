from django.shortcuts import render, get_object_or_404
from .models import Car
from .models import Author
from .models import Tag

def index(request):
    latest = Car.objects.order_by('-created')[:3]
    return render(request, 'cotxes/index.html', {'latest': latest})

def car_list(request):
    cars = Car.objects.order_by('-created')
    return render(request, 'cotxes/car_list.html', {'cars': cars})

def car_detail(request, slug):
    car = get_object_or_404(Car, slug=slug)
    return render(request, 'cotxes/car_detail.html', {'car': car})

def authors_list(request):
    authors = Author.objects.all()
    return render(request, 'cotxes/authors_list.html', {'authors': authors})

def author_detail(request, pk):
    author = get_object_or_404(Author, pk=pk)
    cars = author.cars.all()
    return render(request, 'cotxes/author_detail.html', {'author': author, 'cars': cars})

def tag_list(request):
    tags = Tag.objects.all()
    return render(request, 'cotxes/tag_list.html', {'tags': tags})

def posts_by_tag(request, tag_id):
    tag = get_object_or_404(Tag, pk=tag_id)
    cars = tag.cars.all()
    return render(request, 'cotxes/posts_by_tag.html', {
        'tag': tag,
        'cars': cars
    })